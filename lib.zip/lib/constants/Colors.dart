// ignore_for_file: file_names

import 'package:flutter/material.dart';

const Color tdRed = Color(0xffda4040);
const Color tdBlue = Color(0xff5f52ee);

const Color tdBlack = Color(0xff3a3a3a);

const Color tdGrey = Color(0xff717171);
const Color tdBGcolor = Color(0xffeeeff5);
